// ==========================================
// VERSION: 2.2.0-Ultra-MaxPerformance
// AUTHOR: ThaiThongSj@gmail.com & Gemini
// OPTIMIZATION: Hardened Background Play, Smart Navigation Back, Smooth Rotation
// ==========================================

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_android/webview_flutter_android.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  
  // Thiết lập mặc định hệ thống hiển thị tràn viền
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Colors.transparent,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'YT Premium Ultra',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: Colors.black,
      ),
      home: const SplashScreen(),
    );
  }
}

// =========================================================================
// MÀN HÌNH CHÀO (SPLASH SCREEN) - GIỮ NGUYÊN NGUYÊN BẢN MƯỢT MÀ
// =========================================================================
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1000),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeIn),
    );

    _animationController.forward();

    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (_) => const WebViewScreen()),
        );
      }
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF0F0F0F),
      body: Center(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 90,
                height: 90,
                decoration: BoxDecoration(
                  color: Colors.red.withOpacity(0.1),
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.red, width: 2),
                ),
                child: const Icon(Icons.play_arrow_rounded, size: 55, color: Colors.red),
              ),
              const SizedBox(height: 24),
              const Text(
                'YT PREMIUM ULTRA',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  color: Colors.white,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'ThaiThongSj@gmail.com',
                style: TextStyle(fontSize: 13, color: Colors.grey[500], letterSpacing: 0.5),
              ),
              const SizedBox(height: 40),
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(color: Colors.red, strokeWidth: 2),
              )
            ],
          ),
        ),
      ),
    );
  }
}

// =========================================================================
// MÀN HÌNH CHÍNH - SIÊU CẤP ĐỘ: PHÁT NỀN BẤT TỬ & ĐIỀU HƯỚNG THÔNG MINH
// =========================================================================
class WebViewScreen extends StatefulWidget {
  const WebViewScreen({super.key});

  @override
  State<WebViewScreen> createState() => _WebViewScreenState();
}

class _WebViewScreenState extends State<WebViewScreen> with WidgetsBindingObserver {
  late final WebViewController _controller;
  bool _isLoading = true;
  Orientation? _oldOrientation;

  // HỆ THỐNG SCRIPT SIÊU CẤP V2.2 - VÔ HIỆU HÓA LỆNH TẠM DỪNG TỪ GỐC PROTOTYPE
  final String jungleDiamondLightScript = r"""
(function() {
    'use strict';

    // 1. CHỐNG QUẢNG CÁO & ẨN NÚT GỢI Ý MỞ APP (Giữ nguyên gốc tuyệt đối bảo vệ trải nghiệm)
    const injectStaticShield = () => {
        const css = `
            ytm-ad-slot, ytd-ad-slot-renderer, .ytp-ad-module, .ytp-ad-overlay-container,
            #player-ads, .ad-showing, .ad-interrupting, square-image-layout-view-model,
            ad-image-view-model, ytm-promoted-sparkles-web-renderer, .companion-ad-container,
            .ytm-open-app-button, .compact-app-bar, ytm-pivot-bar-renderer-fast-forward-button {
                display: none !important;
                visibility: hidden !important;
                height: 0 !important;
                width: 0 !important;
                opacity: 0 !important;
                pointer-events: none !important;
            }
        `;
        const style = document.createElement('style');
        style.textContent = css;
        (document.head || document.documentElement).appendChild(style);
    };
    injectStaticShield();

    // 2. BỘ LỌC MẠNG SIÊU NHẸ: HỦY TRUY CẬP CÁC ĐƯỜNG LINK THỐNG KÊ GÂY NẶNG MÁY
    const injectNetworkOptimizer = () => {
        const blacklistedRequests = [
            '/api/stats/ads', '/api/stats/atr', '/api/stats/qoe', 
            'doubleclick.net', 'google-analytics.com', 'pagead/adview', 'ptracking'
        ];
        
        const oldXHR = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url) {
            if (typeof url === 'string' && blacklistedRequests.some(track => url.includes(track))) {
                this.abort();
                return;
            }
            return oldXHR.apply(this, arguments);
        };

        const oldFetch = window.fetch;
        window.fetch = function(input, init) {
            let url = '';
            if (typeof input === 'string') url = input;
            else if (input && input.url) url = input.url;

            if (blacklistedRequests.some(track => url.includes(track))) {
                return Promise.reject(new TypeError('Blocked background analytics for performance'));
            }
            return oldFetch.apply(this, arguments);
        };
    };
    injectNetworkOptimizer();

    // 3. CƠ CHẾ CHẠY NGẦM BẤT TỬ v2.2 HARDENED (BẺ KHÓA PROTOTYPE TRÌNH PHÁT)
    const patchBackgroundEngine = () => {
        Object.defineProperty(document, 'hidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'visibilityState', { get: () => 'visible', configurable: true });
        Object.defineProperty(document, 'webkitHidden', { get: () => false, configurable: true });
        Object.defineProperty(document, 'webkitVisibilityState', { get: () => 'visible', configurable: true });
        
        window.addEventListener('visibilitychange', (e) => e.stopImmediatePropagation(), true);
        window.addEventListener('webkitvisibilitychange', (e) => e.stopImmediatePropagation(), true);
        window.addEventListener('pagehide', (e) => e.stopImmediatePropagation(), true);
        window.addEventListener('blur', (e) => e.stopImmediatePropagation(), true);

        // Đè MediaSession chặn lệnh pause từ hệ điều hành phát ra khi ẩn app
        if (navigator.mediaSession) {
            navigator.mediaSession.setActionHandler('pause', () => {});
        }

        // Đè trực tiếp hàm pause của thẻ Video gốc - Chặn đứng YouTube gọi lệnh dừng khi mất focus
        const originalPause = HTMLMediaElement.prototype.pause;
        HTMLMediaElement.prototype.pause = function() {
            if (document.hasFocus && !document.hasFocus()) {
                // Nếu app đang chạy ngầm (mất focus), bỏ qua hoàn toàn lệnh pause này
                return Promise.resolve();
            }
            return originalPause.apply(this, arguments);
        };

        setInterval(() => {
            const video = document.querySelector('video');
            if (video && video.paused && !video.ended) {
                video.play().catch(() => {});
            }
        }, 250);
    };
    patchBackgroundEngine();

    // 4. CƠ CHẾ BỎ QUA QUẢNG CÁO CHỦ ĐỘNG HƯỚNG SỰ KIỆN (TIẾT KIỆM PIN)
    const skipAdLogic = () => {
        const video = document.querySelector('video');
        if (!video) return;

        const adActive = document.querySelector('.ad-showing, .ad-interrupting');
        if (adActive) {
            video.muted = true;
            if (isFinite(video.duration) && video.duration > 0) {
                video.currentTime = video.duration;
            } else {
                video.playbackRate = 16;
            }
            const skipButtons = document.querySelectorAll('.ytp-ad-skip-button, .ytp-skip-ad-button, .ytm-ad-skip-button, button[aria-label*="Skip"], button[aria-label*="Bỏ qua"]');
            skipButtons.forEach(btn => btn.click());
        }
    };

    const initSmartObserver = () => {
        const observer = new MutationObserver(() => {
            skipAdLogic();
            
            const dialog = document.querySelector('yt-confirm-dialog-renderer, tp-yt-paper-dialog, c3-dialog-renderer');
            if (dialog) {
                const text = (dialog.textContent || '').toLowerCase();
                if (/paused|tạm dừng|tiếp tục|continue/.test(text)) {
                    dialog.remove();
                    const video = document.querySelector('video');
                    if (video && video.paused) video.play().catch(() => {});
                }
            }
        });

        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        skipAdLogic();
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSmartObserver);
    } else {
        initSmartObserver();
    }
})();
""";

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);

    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setUserAgent("Mozilla/5.0 (Linux; Android 14; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            setState(() => _isLoading = true);
          },
          onPageFinished: (String url) {
            setState(() => _isLoading = false);
            _controller.runJavaScript(jungleDiamondLightScript).catchError((e) {
              debugPrint("Engine Error: $e");
            });
          },
        ),
      );

    final platform = _controller.platform;
    if (platform is AndroidWebViewController) {
      AndroidWebViewController.enableDebugging(true);
      platform.setMediaPlaybackRequiresUserGesture(false);
    }

    _controller.loadRequest(Uri.parse('https://m.youtube.com'));
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    // Không cho Flutter đóng băng luồng hoạt động của WebView khi thoát ứng dụng ra nền
  }

  // Cập nhật giao diện hệ thống mượt mà, đồng bộ tức thì không gây trễ hình
  void _updateSystemUI(Orientation orientation) {
    if (_oldOrientation == orientation) return;
    _oldOrientation = orientation;

    if (orientation == Orientation.landscape) {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
    } else {
      SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
      SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarColor: Colors.transparent,
        systemNavigationBarIconBrightness: Brightness.light,
      ));
    }
  }

  @override
  Widget build(BuildContext context) {
    final orientation = MediaQuery.of(context).orientation;
    
    // Đồng bộ trực tiếp trạng thái UI hệ thống theo hướng xoay một cách mượt mà nhất
    _updateSystemUI(orientation);

    final bool isLandscape = orientation == Orientation.landscape;

    // Sử dụng PopScope để chặn nút Back hệ thống và xử lý thông minh
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, result) async {
        if (didPop) return;

        // Nếu WebView có lịch sử trang trước đó, quay lại trang trước
        if (await _controller.canGoBack()) {
          await _controller.goBack();
        } else {
          // Nếu ở trang gốc, hiển thị hộp thoại xác nhận thoát bằng Tiếng Anh
          if (context.mounted) {
            final shouldExit = await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                backgroundColor: const Color(0xFF1F1F1F),
                title: const Text('Exit Application', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
                content: const Text('Are you sure you want to exit YT Premium Ultra?', style: TextStyle(color: Colors.grey)),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context, false),
                    child: const Text('Cancel', style: TextStyle(color: Colors.grey)),
                  ),
                  TextButton(
                    onPressed: () => Navigator.pop(context, true),
                    child: const Text('Exit', style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
                  ),
                ],
              ),
            );

            if (shouldExit ?? false) {
              await SystemNavigator.pop(); // Thoát ứng dụng an toàn
            }
          }
        }
      },
      child: Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          top: !isLandscape,
          bottom: !isLandscape,
          left: false,
          right: false,
          child: Stack(
            children: [
              WebViewWidget(controller: _controller),
              if (_isLoading)
                const Center(
                  child: CircularProgressIndicator(
                    color: Colors.red,
                    strokeWidth: 3,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}